Thanks for downloading! Who ever needs to know how to import these object into your scene keep reading.

1. Open your scene and press file in the top left corner.

2. Then press Append(Shortcut: shift + f1).

3. Now search for the blend file you want to open.

4. Then open the Groups folder select the object that has the word Append on it and press enter.

Hope you enjoy!

